// Copyright (c) {year}, {app_publisher} and contributors
// For license information, please see license.txt

frappe.ui.form.on('{doctype}', {{
	// refresh: function(frm) {{

	// }}
}});
