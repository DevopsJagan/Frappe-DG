Leave change log files in this folder for user release notes.

(this file is just a place holder, don't delete it)
