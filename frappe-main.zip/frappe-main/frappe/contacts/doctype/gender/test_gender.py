# Copyright (c) 2017, Frappe Technologies and Contributors
# License: MIT. See LICENSE
from frappe.tests.utils import FrappeTestCase


class TestGender(FrappeTestCase):
	pass
